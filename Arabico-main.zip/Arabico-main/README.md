# CloudStream 3 Disclaimer

> **⚠️ Notice:** This plugin is discontinued. It is now archived and available in a read-only state.

---

### Please read the following carefully:

#### 📝 Content Responsibility
CloudStream 3, along with its extension, does not host or upload any content. It aggregates links that are publicly accessible on third-party websites. We have no control over what media is made available or removed. The app and extension function similarly to search engines like Google, providing links in a user-friendly interface.

#### ⚖️ Legal Concerns
Any legal issues regarding the content accessible through this application or its extension should be addressed directly with the file hosts and providers. CloudStream 3 is not affiliated with these providers. In the case of copyright infringement, please contact the responsible parties or streaming websites directly.

#### 📚 Usage
This app and its extension are intended solely for educational and personal use. Users are responsible for adhering to the laws governing their locality. By using CloudStream 3, you accept full responsibility for your actions.

#### ⚠️ Risks
Use CloudStream 3 and its extension at your own risk. We are not liable for any legal consequences that may arise from the use of this application or its extension.

---

Thank you for using CloudStream 3 and its extension responsibly.
