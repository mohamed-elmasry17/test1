version = 8

cloudstream {
    authors = listOf( "ImZaw" )

	language = "ar"
	
    status = 1

    tvTypes = listOf( "TvSeries" , "Movie" , "Anime" )

    iconUrl = "https://www.google.com/s2/favicons?domain=wecima.tube&sz=%size%"
}
